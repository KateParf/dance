videojs.addLanguage('en-GB', {
  "Color": "Colour"
});