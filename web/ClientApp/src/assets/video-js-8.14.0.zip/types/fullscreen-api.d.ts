export default FullscreenApi;
/**
 * Store the browser-specific methods for the fullscreen API.
 *
 * @type {Object}
 * @see [Specification]{@link https://fullscreen.spec.whatwg.org}
 * @see [Map Approach From Screenfull.js]{@link https://github.com/sindresorhus/screenfull.js}
 */
declare const FullscreenApi: any;
//# sourceMappingURL=fullscreen-api.d.ts.map